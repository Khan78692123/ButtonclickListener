package com.aide.quiz;

import android.app.Activity;
import android.os.Bundle;
import android.widget.Button;
import android.view.View;
import android.widget.Toast;

public class QuizActivity extends Activity
    {
        private Button mTureButton;
        private Button mFalseButton;

        @Override
        protected void onCreate ( Bundle savedInstanceState )
            {
                super.onCreate ( savedInstanceState );
                setContentView ( R.layout.activity_quiz );
                mTureButton = findViewById ( R.id.ture_btn );
                mFalseButton = findViewById ( R.id.false_btn );


                //setUpListeners Ture or False Button
                setUpListeners ( );
            }
        //Ture or False
        private void setUpListeners ( )
            {

                //onClickListener Ture Button
                mTureButton.setOnClickListener ( new View.OnClickListener ( ) {
                            @Override
                            public void onClick ( View v )
                                {

                                    //toast massig  Right
                                    Toast.makeText ( QuizActivity.this, "Right :)", Toast.LENGTH_LONG ).show ( );
                                }
                        } );

                // onClickListener False Button
                mFalseButton.setOnClickListener ( new View.OnClickListener ( ) {
                            @Override
                            public void onClick ( View v )
                                {

                                    //toast massig  Wrong
                                    Toast.makeText ( QuizActivity.this, "Wromg :(", Toast.LENGTH_LONG ).show ( );
                                }
                        } );
            }

    }
